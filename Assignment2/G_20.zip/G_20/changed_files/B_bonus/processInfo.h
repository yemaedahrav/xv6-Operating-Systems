struct processInfo
{
    int ppid;
    int psize;
    int numberContextSwitches;
};
